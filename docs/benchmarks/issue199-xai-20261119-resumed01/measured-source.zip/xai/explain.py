"""연결된 실제 모델에서 XAI 값(IG, SHAP)을 계산한다. 화면 코드와 분리된 순수 계산부.

모델 접근은 predict.ExplainHandle로만 한다. 여기서는 TensorFlow/PyTorch를 직접 쓰지 않는다.
결과 필드는 모델 원출력 단위를 보존한다. 화면은 result.units로 표시 단위를 바꾼다.
"""

import threading
from dataclasses import dataclass, field, replace

import numpy as np

from xai import identity
from xai.units import ExplanationUnits


@dataclass
class IGResult:
    attribution: np.ndarray    # [L] 위치별 기여도 (원출력 단위)
    pred: float                # f(x)
    baseline_pred: float       # f(기준 입력)
    completeness_error: float  # |Σ기여도 − (f(x) − f(기준))|
    units: ExplanationUnits = field(default_factory=ExplanationUnits)


@dataclass
class SHAPResult:
    values: np.ndarray         # [L] 위치별 SHAP 값 (원출력 단위)
    base_value: float          # E[f] (배경 서열 평균 예측)
    pred: float                # f(x)
    additivity_error: float    # |base + Σ SHAP − f(x)|
    # 값을 만든 두 seed (provenance). kernel_shap은 항상 채운다. 직접 만든 결과는 None.
    background_seed: int | None = None   # 배경 서열 seed
    subset_seed: int | None = None       # 부분집합 표본추출 seed
    units: ExplanationUnits = field(default_factory=ExplanationUnits)


#: IG 적분 단계를 한 번에 몇 개씩 역전파할지. 메모리가 부족하면 줄인다.
#: 값에는 영향이 없고 (아래 설명 참고) 최대 메모리 사용량만 달라진다.
IG_CHUNK_SIZE = 8


def integrated_gradients(handle, window_seq: str, steps: int = 64,
                         chunk_size: int = IG_CHUNK_SIZE, on_batch=None) -> IGResult:
    """Integrated Gradients. 기본 기준 입력은 0, NT는 특수 토큰 고정. 중점법 적분.

    적분 단계를 한 배치에 모두 올리면 역전파 그래프가 steps배로 커져 메모리를 많이 쓴다.
    청크로 나눠 기울기 '합'을 누적하고 마지막에 steps로 나누면
    평균을 한 번에 구한 것과 수학적으로 같은 값이 나온다 (mean = sum / steps).

    on_batch(done, total)은 청크 완료마다 적분 단계 수를 보고한다 (total=steps).
    콜백 예외는 호출자에게 전파되며 남은 청크와 완결성 평가를 실행하지 않는다.
    """
    inputs = handle.ig_inputs(window_seq)
    reference_fn = getattr(handle, "ig_baseline", None)
    baseline = reference_fn(inputs) if reference_fn else [np.zeros_like(x) for x in inputs]
    delta = [x - b for x, b in zip(inputs, baseline)]
    alphas = (np.arange(steps) + 0.5) / steps

    chunk = max(1, int(chunk_size))
    sums = [np.zeros(np.shape(x), dtype=np.float64) for x in inputs]
    for i in range(0, steps, chunk):
        a = alphas[i:i + chunk]
        batch = [b[None] + a.reshape((-1,) + (1,) * d.ndim) * d[None]
                 for b, d in zip(baseline, delta)]
        _, grads = handle.ig_grad_fn(batch)
        for s, g in zip(sums, grads):
            s += np.asarray(g, dtype=np.float64).sum(axis=0)
        if on_batch is not None:
            on_batch(min(i + chunk, steps), steps)

    attrs = [d * (s / steps) for d, s in zip(delta, sums)]

    f_x = float(handle.ig_grad_fn([x[None] for x in inputs])[0][0])
    f_0 = float(handle.ig_grad_fn([b[None] for b in baseline])[0][0])
    total = float(sum(a.sum() for a in attrs))
    return IGResult(
        attribution=np.asarray(handle.project(attrs), dtype=np.float64),
        pred=f_x, baseline_pred=f_0,
        completeness_error=abs(total - (f_x - f_0)),
        units=getattr(handle, "units", None) or ExplanationUnits(),
    )


def _onehot(seq: str) -> np.ndarray:
    mapping = {"A": 0, "C": 1, "G": 2, "T": 3}
    out = np.zeros((len(seq), 4), dtype=np.float32)
    for i, b in enumerate(seq.upper()):
        if b in mapping:
            out[i, mapping[b]] = 1.0
    return out


def _random_backgrounds(length: int, n: int, seed: int) -> np.ndarray:
    """seed로 정한 무작위 원핫 배경 n개. 행 우선으로 뽑으므로 n을 늘려도 앞 n개는
    같은 난수열 prefix를 공유한다 (배경 수 비교 실험이 같은 배경 위에서 늘어난다)."""
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, 4, size=(n, length))
    out = np.zeros((n, length, 4), dtype=np.float32)
    np.put_along_axis(out, idx[..., None], 1.0, axis=2)
    return out


def resolve_seeds(seed: int, background_seed: int | None,
                  subset_seed: int | None) -> tuple[int, int]:
    """단일 seed → (배경 seed, 부분집합 seed). 따로 주지 않은 축은 seed를 따른다 (#207).
    kernel_shap과 XAI 메모리 캐시 키가 같은 규칙을 쓰도록 한 곳에 둔다."""
    return (int(seed if background_seed is None else background_seed),
            int(seed if subset_seed is None else subset_seed))


#: 공용 kernel_shap 호출끼리 NumPy 전역 RNG 저장→seed→부분집합 표본추출→복원을
#: 직렬화하는 잠금. 이 함수를 거치는 호출만 서로 보호한다. 전역 RNG를 직접 쓰는
#: 관련 없는 코드가 같은 시각에 끼어드는 것까지 막지는 못한다.
_SHAP_RNG_LOCK = threading.Lock()


def kernel_shap(handle, window_seq: str, nsamples: int = 512,
                n_background: int = 16, seed: int = 0,
                on_batch=None, *, background_seed: int | None = None,
                subset_seed: int | None = None,
                use_disk_cache: bool = True) -> SHAPResult:
    """염기 위치를 특징으로 하는 KernelSHAP.

    '꺼진' 위치는 무작위 배경 서열의 염기로 바꿔 모델에 넣고, 배경 n개의 평균을 쓴다.

    on_batch(done, total) : 진행률 콜백 (ADR 0001). done·total은 모델에 넣은 서열 수다.
        훅은 f(masks) 안이 아니라 handle.raw_fn 안쪽 배치 루프에 걸린다.
        f는 몇 번밖에 불리지 않아 여기에 걸면 진행률이 몇 단계로 끝난다.
        코어는 숫자만 넘기고 표시 문구는 화면이 정한다.

    계산 전에 사전계산 저장소(xai/shap_cache.py)를 먼저 조회한다. 적중하면 추론 없이
    바로 돌려준다. 키 재료는 handle의 model_key(입증된 `ExplanationIdentity`)·head와
    윈도우·설정·두 seed다 (#208). model_key가 이름 문자열뿐이면 식별을 입증할 수
    없으므로 조회하지 않고 계산한다.

    seed는 배경 서열(background_seed)과 shap의 부분집합 표본추출(subset_seed)을
    **함께** 정한다. 둘 다 고정해야 같은 화면을 두 번 열었을 때 같은 기여도가 나온다.
    비교 실험은 background_seed·subset_seed로 한 축씩 따로 바꾼다. 따로 주지 않은
    축은 seed를 따른다. 결과에는 실제로 쓴 두 seed가 남는다.

    동시 호출: 부분집합 표본추출은 NumPy 전역 RNG를 쓴다. 공용 잠금으로 이 함수의
    호출끼리 직렬화하므로, 같은 입력·seed면 동시에 불러도 직렬 호출과 같은 값이 나온다.
    정상 완료·예외·협력 취소(on_batch가 던지는 예외) 모두 호출 전 RNG 상태로 되돌린다.
    shap은 표본추출과 모델 평가를 한 호출 안에서 이어 하므로 잠금은 계산 전체를
    덮는다. on_batch도 잠금 안에서 불리니, 콜백에서 오래 막히거나 다른 kernel_shap
    호출을 기다리면 그동안 다른 호출이 모두 기다린다.
    """
    background_seed, subset_seed = resolve_seeds(seed, background_seed, subset_seed)
    model_identity = identity.verified(getattr(handle, "model_key", None))
    head = getattr(handle, "head", None)
    if use_disk_cache and model_identity is not None and head is not None:
        from xai import shap_cache
        hit = shap_cache.load(shap_cache.shap_cache_key(
            model_identity, head, window_seq, nsamples, n_background,
            background_seed, subset_seed))
        if hit is not None:
            return replace(hit, units=getattr(handle, "units", None) or ExplanationUnits())

    import shap

    onehot = _onehot(window_seq)
    length = onehot.shape[0]
    backgrounds = _random_backgrounds(length, n_background, background_seed)

    # shap은 f를 여러 번 부른다(배경 기준값 1회 + 샘플 1회). 호출마다 0부터 다시 세면
    # 진행률이 뒤로 돌아가므로, 누적 서열 수를 전체 예상치에 대고 보고한다.
    expected = max(1, n_background * (nsamples + 1))
    seen = 0

    def f(masks):
        nonlocal seen
        masks = np.asarray(masks)
        n = masks.shape[0]
        mixed = np.where(masks[:, None, :, None] > 0.5, onehot[None, None], backgrounds[None])
        X = mixed.reshape(n * n_background, length, 4)
        if on_batch is None:
            y = handle.raw_fn(X)
        else:
            base = seen
            y = handle.raw_fn(
                X,
                on_batch=lambda done, _total: on_batch(min(base + done, expected), expected),
            )
            seen = base + X.shape[0]
        return np.asarray(y).reshape(n, n_background).mean(axis=1)

    explainer = shap.KernelExplainer(f, np.zeros((1, length)))
    # shap은 부분집합을 numpy **전역** RNG로 표본추출한다. nsamples가 2^length보다
    # 훨씬 작으므로(기본 64 vs 2^30) 표본추출 결과가 값에 그대로 남는다. seed를
    # 걸지 않으면 같은 입력·같은 설정으로도 호출마다 다른 기여도가 나온다 (#193에서
    # 실측: 같은 seed 재호출로 최대 1.0 차이). 호출자의 RNG 상태는 되돌려 준다.
    # 다른 kernel_shap 호출이 저장과 복원 사이에 seed를 바꾸지 못하게 잠근다. 표본추출과
    # 모델 평가가 shap_values 안에서 이어지므로 계산 전체가 잠금 안에 있다.
    with _SHAP_RNG_LOCK:
        rng_state = np.random.get_state()
        np.random.seed(subset_seed)
        try:
            values = explainer.shap_values(np.ones((1, length)), nsamples=nsamples,
                                           l1_reg=0, silent=True)
        finally:
            np.random.set_state(rng_state)
    values = np.asarray(values, dtype=np.float64).reshape(-1)[:length]
    base = float(np.asarray(explainer.expected_value).reshape(-1)[0])
    pred = float(handle.raw_fn(onehot[None])[0])
    return SHAPResult(values=values, base_value=base, pred=pred,
                      additivity_error=abs(base + values.sum() - pred),
                      background_seed=int(background_seed), subset_seed=int(subset_seed),
                      units=getattr(handle, "units", None) or ExplanationUnits())

@dataclass
class RolloutResult:
    """Attention Rollout 결과.

    token_matrix    : [T, T] 토큰 단위 정보 의존도 (행이 열을 참조하는 정도)
    token_labels    : 토큰 T개의 이름 ('<cls>' 또는 '0-5' 같은 구간)
    position_profile: [L] 위치별로 '얼마나 참조되는지' 합산한 값
    n_layers        : 누적에 쓴 층 수
    """
    token_matrix:     np.ndarray
    token_labels:     list
    position_profile: np.ndarray
    n_layers:         int


def attention_rollout(handle, window_seq: str) -> RolloutResult:
    """Abnar & Zuidema(2020) 방식의 Attention Rollout.

    층마다 헤드를 평균한 뒤 잔차 연결을 단위행렬로 더하고 행 합을 1로 맞춘 다음,
    아래층부터 위층까지 곱해 누적한다. 토큰 기여도는 그 토큰이 덮는 염기에 균등 배분한다.
    """
    if handle.attention_fn is None:
        raise NotImplementedError("이 모델은 attention이 없어 Rollout을 계산할 수 없습니다")

    layers, spans, length = handle.attention_fn(window_seq)
    if not layers:
        raise RuntimeError(
            "모델이 attention 값을 돌려주지 않았습니다. "
            "predict.py의 EsmConfig에 attn_implementation=\"eager\"가 있는지 확인하세요."
        )

    rollout = None
    for att in layers:
        a = np.asarray(att, dtype=np.float64).mean(axis=0)      # 헤드 평균 [T, T]
        a = a + np.eye(a.shape[0])                              # 잔차 연결
        a = a / a.sum(axis=-1, keepdims=True)                   # 행 합 = 1
        rollout = a if rollout is None else a @ rollout

    # 각 토큰이 다른 토큰들로부터 얼마나 참조되는지 (열 방향 합)
    per_token = rollout.sum(axis=0)
    profile = np.zeros(length, dtype=np.float64)
    for value, (start, end) in zip(per_token, spans):
        if end > start:
            stop = min(end, length)
            if stop > start:
                profile[start:stop] += value / (end - start)

    labels = [f"{a}-{b - 1}" if b > a else "special" for a, b in spans]
    return RolloutResult(token_matrix=rollout, token_labels=labels,
                         position_profile=profile, n_layers=len(layers))
